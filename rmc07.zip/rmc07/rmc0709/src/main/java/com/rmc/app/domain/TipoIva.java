package com.rmc.app.domain;

public enum TipoIva {
    SUPERREDUCIDO,
    REDUCIDO,
    NORMAL
}
