package com.rmc.ejerciciosT6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjerciciosT6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
