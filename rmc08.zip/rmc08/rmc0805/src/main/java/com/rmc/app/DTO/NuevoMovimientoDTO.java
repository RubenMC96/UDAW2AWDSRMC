package com.rmc.app.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NuevoMovimientoDTO {
    
    private Float importe;
    private String iban;
}
