package com.rmc.ejerciciosT6.domain;

    public enum Genero { 
        MASCULINO, 
        FEMENINO, 
        OTROS 
    }
